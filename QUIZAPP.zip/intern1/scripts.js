const questions = [
    {
        question: "HTML stands for __________?",
        options: ["HyperText Markup Language", "HyperText Machine Language", "HyperText Marking Language","HighText Markup Language"],
        answer: "HyperText Markup Language"
    },
    {
        question: "Which of the following is used to read an HTML page and render it?",
        options: ["Web server", "Web network", " Web browser","Web matrix"],
        answer: "Web browser"
    },
    {
        question: "Which of the following tag is used for inserting the largest heading in HTML?",
        options: ["head", "<h1>", " <h6>","heading"],
        answer: "<h1>"
    },
    {
        question: "In which part of the HTML metadata is contained?",
        options: ["head tag", " title tag", " html tag","body tag"],
        answer: "head tag"
    },
    {
        question: "How do we write comments in HTML?",
        options: [" </…….>", "<!……>", " </……/>","<…….!>"],
        answer: "<!……>"
    },
    {
        question: "This tag is used to indicate a paragraph in a document?",
        options: ["<Paragraph>", "<Nextline>", "<Para>","<P>"],
        answer: "<P>"
    },

    // Add more questions here
];

let currentQuestion = 0;
let score = 0;
let username = "";

// Initialize leaderboard from local storage
let leaderboardData = JSON.parse(localStorage.getItem("leaderboard")) || [];

function displayQuestion() {
    if (currentQuestion < questions.length) {
        document.getElementById("question").textContent= questions[currentQuestion].question;
        const optionsContainer = document.getElementById("options");
        optionsContainer.innerHTML = "";
        
        questions[currentQuestion].options.forEach((option, index) => {
            const optionButton = document.createElement("button");
            optionButton.textContent = option;
            optionButton.addEventListener("click", () => checkAnswer(option));
            optionsContainer.appendChild(optionButton);
        });
    } else {
        showLeaderboard();
    }
}

function checkAnswer(selectedOption) {
    if (selectedOption === questions[currentQuestion].answer) {
        score++;
    }
    currentQuestion++;
    displayQuestion();
}

function startQuiz() {
    const usernameInput = document.getElementById("username");
    username = usernameInput.value;
    if (username === "") {
        alert("Please enter a username.");
        return;
    }
    document.getElementById("login-container").style.display = "none";
    document.getElementById("quiz-container").style.display = "block";
    displayQuestion();
}

function showLeaderboard() {
    document.getElementById("quiz-container").style.display = "none";
    document.getElementById("leaderboard-container").style.display = "block";
    const leaderboardList = document.getElementById("leaderboard");
    
    // Add the current user's score to the leaderboard
    leaderboardData.push({ username, score });
    leaderboardData.sort((a, b) => b.score - a.score); // Sort by score in descending order
    
    // Store the leaderboard data in local storage
    localStorage.setItem("leaderboard", JSON.stringify(leaderboardData));
    
    
    // Display the leaderboard
    leaderboardList.innerHTML = "";
    leaderboardData.forEach((entry) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${entry.username}: ${entry.score}`;
        leaderboardList.appendChild(listItem);
    });
}

// Initial setup
document.getElementById("login-container").style.display = "block";
